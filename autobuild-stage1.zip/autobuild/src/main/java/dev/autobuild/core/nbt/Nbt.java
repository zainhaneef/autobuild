package dev.autobuild.core.nbt;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Minimal, dependency-free NBT reader/writer (big-endian, optionally gzip-compressed).
 * Mapping: byte->Byte, short->Short, int->Integer, long->Long, float->Float, double->Double,
 * byte[]/int[]/long[] -> arrays, string->String, list->List&lt;Object&gt;, compound->Map&lt;String,Object&gt;.
 */
public final class Nbt {
    private Nbt() {}

    public static Map<String, Object> readFile(Path file) throws IOException {
        return read(Files.readAllBytes(file));
    }

    public static Map<String, Object> read(byte[] data) throws IOException {
        InputStream in = new ByteArrayInputStream(data);
        if (data.length > 2 && (data[0] & 0xFF) == 0x1F && (data[1] & 0xFF) == 0x8B) {
            in = new GZIPInputStream(in);
        }
        try (DataInputStream d = new DataInputStream(new BufferedInputStream(in))) {
            int type = d.readUnsignedByte();
            if (type != 10) throw new IOException("Root tag is not a compound (type " + type + ")");
            d.readUTF(); // root name
            @SuppressWarnings("unchecked")
            Map<String, Object> root = (Map<String, Object>) readPayload(d, 10, 0);
            return root;
        }
    }

    private static Object readPayload(DataInputStream d, int type, int depth) throws IOException {
        if (depth > 512) throw new IOException("NBT nesting too deep");
        switch (type) {
            case 1: return d.readByte();
            case 2: return d.readShort();
            case 3: return d.readInt();
            case 4: return d.readLong();
            case 5: return d.readFloat();
            case 6: return d.readDouble();
            case 7: { int n = checkLen(d.readInt()); byte[] a = new byte[n]; d.readFully(a); return a; }
            case 8: return d.readUTF();
            case 9: {
                int et = d.readUnsignedByte();
                int n = checkLen(d.readInt());
                List<Object> l = new ArrayList<>(Math.min(n, 4096));
                for (int i = 0; i < n; i++) l.add(readPayload(d, et, depth + 1));
                return l;
            }
            case 10: {
                Map<String, Object> m = new LinkedHashMap<>();
                while (true) {
                    int t = d.readUnsignedByte();
                    if (t == 0) break;
                    String k = d.readUTF();
                    m.put(k, readPayload(d, t, depth + 1));
                }
                return m;
            }
            case 11: { int n = checkLen(d.readInt()); int[] a = new int[n]; for (int i = 0; i < n; i++) a[i] = d.readInt(); return a; }
            case 12: { int n = checkLen(d.readInt()); long[] a = new long[n]; for (int i = 0; i < n; i++) a[i] = d.readLong(); return a; }
            default: throw new IOException("Unknown NBT tag type " + type);
        }
    }

    private static int checkLen(int n) throws IOException {
        if (n < 0) throw new IOException("Negative NBT array/list length");
        return n;
    }

    // ---------------------------------------------------------------- writing

    public static void writeCompressed(Path file, Map<String, Object> root, String rootName) throws IOException {
        try (OutputStream os = Files.newOutputStream(file);
             DataOutputStream d = new DataOutputStream(new BufferedOutputStream(new GZIPOutputStream(os)))) {
            d.writeByte(10);
            d.writeUTF(rootName);
            writePayload(d, root);
        }
    }

    @SuppressWarnings("unchecked")
    private static void writePayload(DataOutputStream d, Object v) throws IOException {
        if (v instanceof Byte b) d.writeByte(b);
        else if (v instanceof Short s) d.writeShort(s);
        else if (v instanceof Integer i) d.writeInt(i);
        else if (v instanceof Long l) d.writeLong(l);
        else if (v instanceof Float f) d.writeFloat(f);
        else if (v instanceof Double db) d.writeDouble(db);
        else if (v instanceof byte[] a) { d.writeInt(a.length); d.write(a); }
        else if (v instanceof String s) d.writeUTF(s);
        else if (v instanceof int[] a) { d.writeInt(a.length); for (int x : a) d.writeInt(x); }
        else if (v instanceof long[] a) { d.writeInt(a.length); for (long x : a) d.writeLong(x); }
        else if (v instanceof List<?> l) {
            int et = l.isEmpty() ? 0 : typeOf(l.get(0));
            d.writeByte(et);
            d.writeInt(l.size());
            for (Object o : l) writePayload(d, o);
        } else if (v instanceof Map<?, ?> m) {
            for (Map.Entry<String, Object> e : ((Map<String, Object>) m).entrySet()) {
                d.writeByte(typeOf(e.getValue()));
                d.writeUTF(e.getKey());
                writePayload(d, e.getValue());
            }
            d.writeByte(0);
        } else throw new IOException("Unsupported NBT value: " + v);
    }

    private static int typeOf(Object v) throws IOException {
        if (v instanceof Byte) return 1;
        if (v instanceof Short) return 2;
        if (v instanceof Integer) return 3;
        if (v instanceof Long) return 4;
        if (v instanceof Float) return 5;
        if (v instanceof Double) return 6;
        if (v instanceof byte[]) return 7;
        if (v instanceof String) return 8;
        if (v instanceof List) return 9;
        if (v instanceof Map) return 10;
        if (v instanceof int[]) return 11;
        if (v instanceof long[]) return 12;
        throw new IOException("Unsupported NBT value type: " + v);
    }

    // ---------------------------------------------------------------- typed accessors

    @SuppressWarnings("unchecked")
    public static Map<String, Object> compound(Map<String, Object> m, String key) {
        Object o = m.get(key);
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> list(Map<String, Object> m, String key) {
        Object o = m.get(key);
        return o instanceof List ? (List<Object>) o : null;
    }

    public static int intVal(Map<String, Object> m, String key, int def) {
        Object o = m.get(key);
        return o instanceof Number n ? n.intValue() : def;
    }

    public static String string(Map<String, Object> m, String key, String def) {
        Object o = m.get(key);
        return o instanceof String s ? s : def;
    }

    public static long[] longArray(Map<String, Object> m, String key) {
        Object o = m.get(key);
        return o instanceof long[] a ? a : null;
    }
}
