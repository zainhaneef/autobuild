package dev.autobuild.core.compare;

import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.model.PlacedSchematic;
import dev.autobuild.core.model.Pos;
import dev.autobuild.core.schematic.Schematic;

import java.util.ArrayList;
import java.util.List;

public class WorldComparator {
    public static class Difference {
        public final Pos worldPos;
        public final BlockStateKey targetState;
        public final String worldBlockName;

        public Difference(Pos worldPos, BlockStateKey targetState, String worldBlockName) {
            this.worldPos = worldPos;
            this.targetState = targetState;
            this.worldBlockName = worldBlockName;
        }
    }

    public static List<Difference> compareSchematic(PlacedSchematic placed) {
        List<Difference> diffs = new ArrayList<>();
        Schematic sch = placed.getSchematic();
        Pos origin = placed.getOrigin();

        for (Schematic.Region reg : sch.getRegions().values()) {
            Pos regPos = reg.getPosition().add(origin);
            Pos size = reg.getSize();
            for (int y = 0; y < size.y; y++) {
                for (int z = 0; z < size.z; z++) {
                    for (int x = 0; x < size.x; x++) {
                        BlockStateKey target = reg.getBlockAt(x, y, z);
                        if (!target.getName().equals("minecraft:air")) {
                            diffs.add(new Difference(regPos.add(x, y, z), target, "minecraft:air"));
                        }
                    }
                }
            }
        }
        return diffs;
    }
}
