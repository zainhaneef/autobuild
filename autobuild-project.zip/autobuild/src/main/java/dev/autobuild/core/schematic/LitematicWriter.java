package dev.autobuild.core.schematic;

import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.model.Pos;
import dev.autobuild.core.nbt.Nbt;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class LitematicWriter {
    public static void write(Schematic schematic, File file) throws IOException {
        Nbt.CompoundTag root = new Nbt.CompoundTag();
        root.put("DataVersion", 4185);
        Nbt.CompoundTag meta = new Nbt.CompoundTag();
        meta.put("Name", schematic.getName());
        root.put("Metadata", meta);

        Nbt.CompoundTag regionsTag = new Nbt.CompoundTag();
        for (Map.Entry<String, Schematic.Region> entry : schematic.getRegions().entrySet()) {
            regionsTag.put(entry.getKey(), serializeRegion(entry.getValue()));
        }
        root.put("Regions", regionsTag);
        Nbt.writeCompressed(root, file);
    }

    private static Nbt.CompoundTag serializeRegion(Schematic.Region region) {
        Nbt.CompoundTag tag = new Nbt.CompoundTag();
        Pos pos = region.getPosition();
        Nbt.CompoundTag pTag = new Nbt.CompoundTag();
        pTag.put("x", pos.x); pTag.put("y", pos.y); pTag.put("z", pos.z);
        tag.put("Position", pTag);

        Pos size = region.getSize();
        Nbt.CompoundTag sTag = new Nbt.CompoundTag();
        sTag.put("x", size.x); sTag.put("y", size.y); sTag.put("z", size.z);
        tag.put("Size", sTag);

        List<Object> paletteList = new ArrayList<>();
        for (BlockStateKey key : region.getPalette()) {
            Nbt.CompoundTag st = new Nbt.CompoundTag();
            st.put("Name", key.getName());
            paletteList.add(st);
        }
        tag.put("BlockStatePalette", paletteList);
        tag.put("BlockStates", new long[0]);
        return tag;
    }
}
