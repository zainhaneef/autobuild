package dev.autobuild.core.schematic;

import dev.autobuild.core.compare.StateMatcher;
import dev.autobuild.core.compare.WorldComparator;
import dev.autobuild.core.compare.WorldComparator.Report;
import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.model.PlacedSchematic;
import dev.autobuild.core.model.Pos;
import dev.autobuild.core.model.Transform;
import dev.autobuild.core.model.Transform.Mirror;
import dev.autobuild.core.nbt.Nbt;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Plain-main test runner so the pure-Java core can be verified without any test framework. */
public final class SelfTest {
    private static int passed, failed;

    private static void check(boolean ok, String what) {
        if (ok) { passed++; System.out.println("  ok    " + what); }
        else { failed++; System.out.println("  FAIL  " + what); }
    }

    private static void eq(Object expected, Object actual, String what) {
        boolean ok = Objects.equals(expected, actual);
        check(ok, ok ? what : what + " (expected " + expected + " but was " + actual + ")");
    }

    private static BlockStateKey tf(String state, int steps, Mirror m) {
        return StateTransformer.transform(BlockStateKey.parse(state), new Transform(steps, m));
    }

    public static void main(String[] args) throws Exception {
        System.out.println("bit packing");
        Random rnd = new Random(42);
        for (int paletteSize : new int[]{2, 3, 5, 9, 17, 33, 200, 1000, 70000}) {
            int n = 5000;
            int[] idx = new int[n];
            for (int i = 0; i < n; i++) idx[i] = rnd.nextInt(paletteSize);
            long[] packed = LitematicWriter.packBlocks(idx, paletteSize);
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(paletteSize - 1));
            long mask = (1L << bits) - 1;
            boolean same = true;
            for (int i = 0; i < n; i++) same &= LitematicReader.getPacked(packed, i, bits, mask) == idx[i];
            check(same, "round trip, palette size " + paletteSize + " (" + bits + " bits)");
        }

        System.out.println("nbt");
        Path tmp = Files.createTempDirectory("autobuild-test");
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("a", 1); m.put("b", "text"); m.put("c", new long[]{1L, -2L}); m.put("d", List.of(1, 2, 3));
        Path nbtFile = tmp.resolve("t.nbt");
        Nbt.writeCompressed(nbtFile, m, "");
        Map<String, Object> back = Nbt.readFile(nbtFile);
        eq(1, back.get("a"), "int");
        eq("text", back.get("b"), "string");
        check(Arrays.equals(new long[]{1L, -2L}, (long[]) back.get("c")), "long array");
        eq(List.of(1, 2, 3), back.get("d"), "int list");

        System.out.println("litematic file round trip");
        Schematic house = TestStructures.smallHouse();
        Path file = tmp.resolve("house.litematic");
        LitematicWriter.write(house, file, "AutoBuild");
        Schematic read = LitematicReader.read(file);
        eq(house.sizeX + "x" + house.sizeY + "x" + house.sizeZ, read.sizeX + "x" + read.sizeY + "x" + read.sizeZ, "size");
        boolean cellsEqual = true;
        for (int i = 0; i < house.volume(); i++) cellsEqual &= house.stateAtIndex(i).equals(read.stateAtIndex(i));
        check(cellsEqual, "every cell state identical (" + house.volume() + " cells)");
        eq(house.countNonAir(), read.countNonAir(), "non-air count " + house.countNonAir());

        System.out.println("multi-region + negative size");
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("Version", 6);
        root.put("MinecraftDataVersion", 4671);
        Map<String, Object> meta = new LinkedHashMap<>();
        meta.put("Name", "multi");
        root.put("Metadata", meta);
        Map<String, Object> regions = new LinkedHashMap<>();
        regions.put("A", region(0, 0, 0, 2, 1, 1, new String[]{"minecraft:stone", "minecraft:dirt"}, new int[]{0, 1}));
        // Position x=4, Size x=-2 => covers x = 3..4
        regions.put("B", region(4, 0, 0, -2, 1, 1, new String[]{"minecraft:gold_block", "minecraft:iron_block"}, new int[]{0, 1}));
        root.put("Regions", regions);
        Schematic multi = LitematicReader.fromRoot(root, "x");
        eq(5, multi.sizeX, "merged width");
        eq("minecraft:stone", multi.stateAt(0, 0, 0).toString(), "region A cell 0");
        eq("minecraft:dirt", multi.stateAt(1, 0, 0).toString(), "region A cell 1");
        eq("minecraft:air", multi.stateAt(2, 0, 0).toString(), "gap is air");
        eq("minecraft:gold_block", multi.stateAt(3, 0, 0).toString(), "negative region first cell at min corner");
        eq("minecraft:iron_block", multi.stateAt(4, 0, 0).toString(), "negative region second cell");

        System.out.println("position transforms");
        Schematic marker = new SchematicBuilder("m", 0, 3, 1, 2).fill(0, 0, 0, 2, 0, 1, "minecraft:stone").set(0, 0, 0, "minecraft:gold_block").build();
        Schematic cw = marker.transformed(new Transform(1, Mirror.NONE));
        eq("2x1x3", cw.sizeX + "x" + cw.sizeY + "x" + cw.sizeZ, "CW90 size");
        eq("minecraft:gold_block", cw.stateAt(1, 0, 0).toString(), "CW90 marker position");
        Schematic ccw = marker.transformed(new Transform(3, Mirror.NONE));
        eq("minecraft:gold_block", ccw.stateAt(0, 0, 2).toString(), "CCW90 marker position");
        Schematic r180 = marker.transformed(new Transform(2, Mirror.NONE));
        eq("minecraft:gold_block", r180.stateAt(2, 0, 1).toString(), "180 marker position");
        eq("minecraft:gold_block", marker.transformed(new Transform(0, Mirror.LEFT_RIGHT)).stateAt(0, 0, 1).toString(), "LEFT_RIGHT flips Z");
        eq("minecraft:gold_block", marker.transformed(new Transform(0, Mirror.FRONT_BACK)).stateAt(2, 0, 0).toString(), "FRONT_BACK flips X");

        System.out.println("transform identities on the test house");
        Schematic r4 = house;
        for (int i = 0; i < 4; i++) r4 = r4.transformed(new Transform(1, Mirror.NONE));
        boolean id4 = true;
        for (int i = 0; i < house.volume(); i++) id4 &= house.stateAtIndex(i).equals(r4.stateAtIndex(i));
        check(id4, "four CW90 rotations restore the schematic");
        for (Mirror mir : new Mirror[]{Mirror.LEFT_RIGHT, Mirror.FRONT_BACK}) {
            Schematic mm = house.transformed(new Transform(0, mir)).transformed(new Transform(0, mir));
            boolean idm = true;
            for (int i = 0; i < house.volume(); i++) idm &= house.stateAtIndex(i).equals(mm.stateAtIndex(i));
            check(idm, "double " + mir + " restores the schematic");
        }
        Schematic cwccw = house.transformed(new Transform(1, Mirror.NONE)).transformed(new Transform(3, Mirror.NONE));
        boolean idr = true;
        for (int i = 0; i < house.volume(); i++) idr &= house.stateAtIndex(i).equals(cwccw.stateAtIndex(i));
        check(idr, "CW90 then CCW90 restores the schematic");
        eq(house.countNonAir(), house.transformed(new Transform(1, Mirror.LEFT_RIGHT)).countNonAir(), "block count preserved by transform");

        System.out.println("state transforms");
        eq("minecraft:oak_stairs[facing=east,half=bottom,shape=outer_left]", tf("minecraft:oak_stairs[facing=north,half=bottom,shape=outer_left]", 1, Mirror.NONE).toString(), "stairs rotate CW90");
        eq("minecraft:oak_stairs[facing=south,half=bottom,shape=outer_right]", tf("minecraft:oak_stairs[facing=north,half=bottom,shape=outer_left]", 0, Mirror.LEFT_RIGHT).toString(), "stairs LEFT_RIGHT: facing flips, shape swaps");
        eq("minecraft:oak_stairs[facing=north,half=bottom,shape=inner_left]", tf("minecraft:oak_stairs[facing=north,half=bottom,shape=inner_right]", 0, Mirror.FRONT_BACK).toString(), "stairs FRONT_BACK: shape swaps");
        eq("z", tf("minecraft:oak_log[axis=x]", 1, Mirror.NONE).get("axis"), "log axis x->z");
        eq("y", tf("minecraft:oak_log[axis=y]", 1, Mirror.NONE).get("axis"), "log axis y unchanged");
        eq("x", tf("minecraft:oak_log[axis=x]", 0, Mirror.LEFT_RIGHT).get("axis"), "log axis unchanged by mirror");
        eq("8", tf("minecraft:oak_sign[rotation=4]", 1, Mirror.NONE).get("rotation"), "sign rotation CW90 (west->north)");
        eq("12", tf("minecraft:oak_sign[rotation=4]", 0, Mirror.FRONT_BACK).get("rotation"), "sign rotation FRONT_BACK (west->east)");
        eq("8", tf("minecraft:oak_sign[rotation=0]", 0, Mirror.LEFT_RIGHT).get("rotation"), "sign rotation LEFT_RIGHT (south->north)");
        BlockStateKey fence = tf("minecraft:oak_fence[east=true,north=false,south=false,west=false]", 1, Mirror.NONE);
        eq("true", fence.get("south"), "fence east->south");
        eq("false", fence.get("east"), "fence east cleared");
        eq("minecraft:rail[shape=south_west]", tf("minecraft:rail[shape=south_east]", 1, Mirror.NONE).toString(), "rail curve CW90");
        eq("minecraft:rail[shape=east_west]", tf("minecraft:rail[shape=north_south]", 1, Mirror.NONE).toString(), "rail straight CW90");
        eq("minecraft:powered_rail[shape=ascending_south]", tf("minecraft:powered_rail[shape=ascending_east]", 1, Mirror.NONE).toString(), "rail ascending CW90");
        eq("right", tf("minecraft:oak_door[facing=north,hinge=left]", 0, Mirror.FRONT_BACK).get("hinge"), "door hinge mirrors");
        eq("right", tf("minecraft:chest[facing=north,type=left]", 0, Mirror.FRONT_BACK).get("type"), "chest half mirrors");
        eq("east", tf("minecraft:wall_torch[facing=north]", 1, Mirror.NONE).get("facing"), "wall torch rotates");

        System.out.println("world comparison");
        Schematic cs = new SchematicBuilder("c", 0, 4, 1, 1)
                .set(0, 0, 0, "minecraft:stone")
                .set(1, 0, 0, "minecraft:oak_stairs[facing=north,half=bottom,shape=straight]")
                .set(3, 0, 0, "minecraft:dirt").build();
        PlacedSchematic placed = new PlacedSchematic(cs, new Pos(10, 64, 10));
        Map<Pos, BlockStateKey> world = new HashMap<>();
        world.put(new Pos(10, 64, 10), BlockStateKey.parse("minecraft:stone"));
        world.put(new Pos(11, 64, 10), BlockStateKey.parse("minecraft:oak_stairs[facing=north,half=bottom,shape=outer_left]"));
        world.put(new Pos(12, 64, 10), BlockStateKey.parse("minecraft:cobblestone")); // expected air -> EXTRA
        // (13,64,10) deliberately absent -> UNKNOWN
        Report exact = WorldComparator.compare(placed, world::get, StateMatcher.Mode.EXACT);
        Report place = WorldComparator.compare(placed, world::get, StateMatcher.Mode.PLACEMENT);
        eq(1, exact.match, "EXACT: only stone matches");
        eq(1, exact.incorrect, "EXACT: stair shape difference is incorrect");
        eq(2, place.match, "PLACEMENT: derived 'shape' ignored");
        eq(0, place.incorrect, "PLACEMENT: no incorrect cells");
        eq(1, place.extra, "extra block where schematic wants air");
        eq(1, place.unknown, "unloaded position is UNKNOWN, not MISSING");
        world.put(new Pos(13, 64, 10), BlockStateKey.parse("minecraft:oak_planks"));
        eq(1, WorldComparator.compare(placed, world::get, StateMatcher.Mode.PLACEMENT).incorrect, "occupied-but-wrong block is INCORRECT, not done");
        world.put(new Pos(13, 64, 10), BlockStateKey.AIR);
        eq(1, WorldComparator.compare(placed, world::get, StateMatcher.Mode.PLACEMENT).missing, "air where block expected is MISSING");
        eq(10, placed.worldPos(0).x(), "world position mapping");
        eq(3, placed.indexOf(new Pos(13, 64, 10)), "index lookup");
        eq(-1, placed.indexOf(new Pos(14, 64, 10)), "index lookup outside box");

        System.out.println();
        System.out.println(passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }

    private static Map<String, Object> region(int px, int py, int pz, int sx, int sy, int sz, String[] palette, int[] cells) {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("Position", LitematicWriter.vec(px, py, pz));
        r.put("Size", LitematicWriter.vec(sx, sy, sz));
        BlockStateKey[] pal = new BlockStateKey[palette.length];
        for (int i = 0; i < pal.length; i++) pal[i] = BlockStateKey.parse(palette[i]);
        r.put("BlockStatePalette", LitematicWriter.paletteList(pal));
        r.put("BlockStates", LitematicWriter.packBlocks(cells, palette.length));
        return r;
    }
}
