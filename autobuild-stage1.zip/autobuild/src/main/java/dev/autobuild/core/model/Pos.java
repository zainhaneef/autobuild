package dev.autobuild.core.model;

/** Immutable integer block position (independent of Minecraft classes). */
public record Pos(int x, int y, int z) {
    public Pos add(int dx, int dy, int dz) { return new Pos(x + dx, y + dy, z + dz); }

    @Override public String toString() { return x + ", " + y + ", " + z; }
}
