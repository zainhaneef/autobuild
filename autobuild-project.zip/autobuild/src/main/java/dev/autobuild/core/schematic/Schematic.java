package dev.autobuild.core.schematic;

import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.model.Pos;

import java.util.*;

public class Schematic {
    private final String name;
    private final Map<String, Region> regions;

    public static class Region {
        private final String name;
        private final Pos position, size;
        private final List<BlockStateKey> palette;
        private final int[] blockStates;

        public Region(String name, Pos position, Pos size, List<BlockStateKey> palette, int[] blockStates) {
            this.name = name;
            this.position = position;
            this.size = size;
            this.palette = palette;
            this.blockStates = blockStates;
        }

        public String getName() { return name; }
        public Pos getPosition() { return position; }
        public Pos getSize() { return size; }
        public List<BlockStateKey> getPalette() { return palette; }
        public int[] getBlockStates() { return blockStates; }

        public BlockStateKey getBlockAt(int x, int y, int z) {
            if (x < 0 || x >= size.x || y < 0 || y >= size.y || z < 0 || z >= size.z) {
                return new BlockStateKey("minecraft:air", Collections.emptyMap());
            }
            int index = (y * size.z + z) * size.x + x;
            if (index < 0 || index >= blockStates.length) return new BlockStateKey("minecraft:air", Collections.emptyMap());
            int paletteIndex = blockStates[index];
            return paletteIndex >= 0 && paletteIndex < palette.size() ? palette.get(paletteIndex) : new BlockStateKey("minecraft:air", Collections.emptyMap());
        }
    }

    public Schematic(String name, Map<String, Region> regions) {
        this.name = name;
        this.regions = regions;
    }

    public String getName() { return name; }
    public Map<String, Region> getRegions() { return regions; }

    public int getTotalBlocks() {
        int total = 0;
        for (Region reg : regions.values()) {
            for (int state : reg.blockStates) {
                if (state >= 0 && state < reg.palette.size()) {
                    String name = reg.palette.get(state).getName();
                    if (!name.equals("minecraft:air") && !name.equals("minecraft:cave_air")) total++;
                }
            }
        }
        return total;
    }

    public Map<String, Integer> getMaterialRequirements() {
        Map<String, Integer> reqs = new HashMap<>();
        for (Region reg : regions.values()) {
            for (int state : reg.blockStates) {
                if (state >= 0 && state < reg.palette.size()) {
                    String name = reg.palette.get(state).getName();
                    if (!name.equals("minecraft:air") && !name.equals("minecraft:cave_air")) {
                        reqs.put(name, reqs.getOrDefault(name, 0) + 1);
                    }
                }
            }
        }
        return reqs;
    }
}
