package dev.autobuild.core.model;

/**
 * Mirror is applied first, then rotation (same order as vanilla structure placement).
 * Rotation is clockwise when viewed from above (north -> east).
 * LEFT_RIGHT flips the Z axis (north<->south); FRONT_BACK flips the X axis (east<->west).
 */
public record Transform(int rotationSteps, Mirror mirror) {
    public enum Mirror { NONE, LEFT_RIGHT, FRONT_BACK }

    public static final Transform IDENTITY = new Transform(0, Mirror.NONE);

    public Transform {
        rotationSteps = ((rotationSteps % 4) + 4) % 4;
        if (mirror == null) mirror = Mirror.NONE;
    }

    public boolean isIdentity() { return rotationSteps == 0 && mirror == Mirror.NONE; }

    private static final String[] CW = {"north", "east", "south", "west"};

    /** Transforms a horizontal direction name; up/down and unknown strings pass through. */
    public String dir(String d) {
        String m = d;
        if (mirror == Mirror.LEFT_RIGHT) {
            if (d.equals("north")) m = "south"; else if (d.equals("south")) m = "north";
        } else if (mirror == Mirror.FRONT_BACK) {
            if (d.equals("east")) m = "west"; else if (d.equals("west")) m = "east";
        }
        for (int i = 0; i < 4; i++) {
            if (CW[i].equals(m)) return CW[(i + rotationSteps) % 4];
        }
        return m;
    }
}
