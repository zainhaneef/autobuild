package dev.autobuild.core.schematic;

/** Small bundled test structure that exercises many placement rules (stairs, doors, torches, gravity, ...). */
public final class TestStructures {
    private TestStructures() {}

    /** Data version for Minecraft 1.21.11 (metadata only; the parser does not depend on it). */
    public static final int DATA_VERSION_1_21_11 = 4671;

    /** 7 x 7 x 7 cottage: stone floor, plank walls, log corners, door, panes, stair/slab roof, props. */
    public static Schematic smallHouse() {
        SchematicBuilder b = new SchematicBuilder("autobuild_test_house", DATA_VERSION_1_21_11, 7, 7, 7);
        b.fill(0, 0, 0, 6, 0, 6, "minecraft:stone_bricks");

        // walls (hollow ring), y = 1..3
        for (int y = 1; y <= 3; y++) {
            b.fill(0, y, 0, 6, y, 0, "minecraft:oak_planks");
            b.fill(0, y, 6, 6, y, 6, "minecraft:oak_planks");
            b.fill(0, y, 0, 0, y, 6, "minecraft:oak_planks");
            b.fill(6, y, 0, 6, y, 6, "minecraft:oak_planks");
        }
        for (int y = 1; y <= 3; y++) {
            for (int[] c : new int[][]{{0, 0}, {0, 6}, {6, 0}, {6, 6}}) {
                b.set(c[0], y, c[1], "minecraft:oak_log[axis=y]");
            }
        }

        // door in the north wall (z = 0) at x = 3
        b.set(3, 1, 0, "minecraft:oak_door[facing=north,half=lower,hinge=left,open=false,powered=false]");
        b.set(3, 2, 0, "minecraft:oak_door[facing=north,half=upper,hinge=left,open=false,powered=false]");

        // windows replace planks at y = 2
        b.set(1, 2, 0, "minecraft:glass_pane[east=true,north=false,south=false,waterlogged=false,west=true]");
        b.set(5, 2, 0, "minecraft:glass_pane[east=true,north=false,south=false,waterlogged=false,west=true]");
        b.set(0, 2, 3, "minecraft:glass_pane[east=false,north=true,south=true,waterlogged=false,west=false]");

        // ceiling and gable roof along the x axis (stairs rise toward the ridge)
        b.fill(0, 4, 1, 6, 4, 5, "minecraft:oak_planks");
        b.fill(1, 5, 2, 5, 5, 4, "minecraft:oak_planks");
        for (int x = 0; x <= 6; x++) {
            b.set(x, 4, 0, "minecraft:spruce_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]");
            b.set(x, 4, 6, "minecraft:spruce_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]");
        }
        for (int x = 0; x <= 6; x++) {
            b.set(x, 5, 1, "minecraft:spruce_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]");
            b.set(x, 5, 5, "minecraft:spruce_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]");
            b.set(x, 6, 2, "minecraft:spruce_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]");
            b.set(x, 6, 4, "minecraft:spruce_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]");
            b.set(x, 6, 3, "minecraft:spruce_slab[type=bottom,waterlogged=false]");
        }

        // interior props
        b.set(1, 2, 3, "minecraft:wall_torch[facing=east]");
        b.set(5, 1, 5, "minecraft:torch");
        b.set(2, 1, 5, "minecraft:sand");
        b.set(2, 2, 5, "minecraft:sand");
        b.set(1, 1, 5, "minecraft:ladder[facing=east,waterlogged=false]");
        b.set(3, 1, 5, "minecraft:chest[facing=north,type=single,waterlogged=false]");
        b.set(4, 1, 1, "minecraft:oak_fence[east=false,north=false,south=false,waterlogged=false,west=false]");
        b.set(4, 2, 1, "minecraft:lantern[hanging=false,waterlogged=false]");
        b.set(5, 1, 1, "minecraft:oak_sign[rotation=4,waterlogged=false]");
        return b.build();
    }
}
