package dev.autobuild.core.schematic;

import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.model.Pos;
import dev.autobuild.core.model.Transform;

import java.util.*;

/**
 * Dense, immutable-by-convention schematic: a palette plus one palette index per cell.
 * Cell index = (y * sizeZ + z) * sizeX + x. Coordinates are relative to the schematic's minimum corner.
 */
public final class Schematic {
    public final String name;
    public final int dataVersion;
    public final int sizeX, sizeY, sizeZ;
    public final BlockStateKey[] palette;
    public final int[] blocks;
    private final boolean[] airFlags;

    public Schematic(String name, int dataVersion, int sx, int sy, int sz, BlockStateKey[] palette, int[] blocks) {
        if ((long) sx * sy * sz != blocks.length) throw new IllegalArgumentException("blocks.length != volume");
        this.name = name;
        this.dataVersion = dataVersion;
        this.sizeX = sx;
        this.sizeY = sy;
        this.sizeZ = sz;
        this.palette = palette;
        this.blocks = blocks;
        this.airFlags = new boolean[palette.length];
        for (int i = 0; i < palette.length; i++) airFlags[i] = palette[i].isAir();
    }

    public int volume() { return blocks.length; }

    public int index(int x, int y, int z) { return (y * sizeZ + z) * sizeX + x; }

    public boolean inBounds(int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < sizeX && y < sizeY && z < sizeZ;
    }

    public BlockStateKey stateAt(int x, int y, int z) { return palette[blocks[index(x, y, z)]]; }

    public BlockStateKey stateAtIndex(int index) { return palette[blocks[index]]; }

    public boolean isAirIndex(int index) { return airFlags[blocks[index]]; }

    public Pos posOfIndex(int index) {
        int x = index % sizeX;
        int rest = index / sizeX;
        int z = rest % sizeZ;
        int y = rest / sizeZ;
        return new Pos(x, y, z);
    }

    public int countNonAir() {
        int n = 0;
        for (int b : blocks) if (!airFlags[b]) n++;
        return n;
    }

    /** Non-air block counts per distinct state, sorted by count descending. */
    public List<Map.Entry<BlockStateKey, Integer>> materialCounts() {
        int[] counts = new int[palette.length];
        for (int b : blocks) counts[b]++;
        Map<BlockStateKey, Integer> m = new HashMap<>();
        for (int i = 0; i < palette.length; i++) if (!airFlags[i] && counts[i] > 0) m.merge(palette[i], counts[i], Integer::sum);
        List<Map.Entry<BlockStateKey, Integer>> l = new ArrayList<>(m.entrySet());
        l.sort((a, b) -> b.getValue() - a.getValue());
        return l;
    }

    /** Returns a new schematic with mirror then rotation applied to positions and block states. */
    public Schematic transformed(Transform t) {
        if (t.isIdentity()) return this;
        int nsx = (t.rotationSteps() & 1) == 1 ? sizeZ : sizeX;
        int nsz = (t.rotationSteps() & 1) == 1 ? sizeX : sizeZ;

        // transform palette (dedupe identical results)
        Map<BlockStateKey, Integer> newIdx = new LinkedHashMap<>();
        int[] remap = new int[palette.length];
        for (int i = 0; i < palette.length; i++) {
            BlockStateKey k = StateTransformer.transform(palette[i], t);
            remap[i] = newIdx.computeIfAbsent(k, kk -> newIdx.size());
        }
        BlockStateKey[] np = newIdx.keySet().toArray(new BlockStateKey[0]);

        int[] nb = new int[blocks.length];
        for (int y = 0; y < sizeY; y++) {
            for (int z = 0; z < sizeZ; z++) {
                for (int x = 0; x < sizeX; x++) {
                    int ox = x, oz = z;
                    if (t.mirror() == Transform.Mirror.LEFT_RIGHT) oz = sizeZ - 1 - oz;
                    else if (t.mirror() == Transform.Mirror.FRONT_BACK) ox = sizeX - 1 - ox;
                    int rx, rz; // after mirror, inside box of original size
                    switch (t.rotationSteps()) {
                        case 1 -> { rx = (sizeZ - 1) - oz; rz = ox; }              // CW 90
                        case 2 -> { rx = (sizeX - 1) - ox; rz = (sizeZ - 1) - oz; } // 180
                        case 3 -> { rx = oz; rz = (sizeX - 1) - ox; }              // CCW 90
                        default -> { rx = ox; rz = oz; }
                    }
                    nb[(y * nsz + rz) * nsx + rx] = remap[blocks[index(x, y, z)]];
                }
            }
        }
        return new Schematic(name, dataVersion, nsx, sizeY, nsz, np, nb);
    }
}
