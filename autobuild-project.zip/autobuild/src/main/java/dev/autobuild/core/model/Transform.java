package dev.autobuild.core.model;

public enum Transform {
    NONE(0, false),
    ROT_90(90, false),
    ROT_180(180, false),
    ROT_270(270, false),
    MIRROR_X(0, true);

    private final int rotationDegrees;
    private final boolean mirrored;

    Transform(int rotationDegrees, boolean mirrored) {
        this.rotationDegrees = rotationDegrees;
        this.mirrored = mirrored;
    }

    public int getRotationDegrees() { return rotationDegrees; }
    public boolean isMirrored() { return mirrored; }
}
