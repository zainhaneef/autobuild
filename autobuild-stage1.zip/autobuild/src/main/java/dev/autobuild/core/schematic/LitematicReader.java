package dev.autobuild.core.schematic;

import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.nbt.Nbt;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/**
 * Reads Litematica {@code .litematic} files (gzip NBT, format versions 5-7).
 * <p>All regions are merged into one dense {@link Schematic} whose origin is the minimum corner
 * of the enclosing box of all regions. Entities and tile-entity data are ignored (block states only).
 * <p>Format notes (as implemented by Litematica): a region's Size components may be negative, in which
 * case the region extends from Position in the negative direction; BlockStates is a bit-packed long
 * array with max(2, ceil(log2(paletteSize))) bits per entry, entries may span two longs, and cell order is
 * (y * |sizeZ| + z) * |sizeX| + x.
 */
public final class LitematicReader {
    private LitematicReader() {}

    public static final int MAX_CELLS = 100_000_000;

    public static class SchematicFormatException extends IOException {
        public SchematicFormatException(String msg) { super(msg); }
    }

    public static Schematic read(Path file) throws IOException {
        String fallback = file.getFileName().toString().replaceFirst("\\.litematic$", "");
        return fromRoot(Nbt.readFile(file), fallback);
    }

    public static Schematic fromRoot(Map<String, Object> root, String fallbackName) throws IOException {
        int version = Nbt.intVal(root, "Version", -1);
        if (version < 5 || version > 7) {
            throw new SchematicFormatException("Unsupported .litematic Version " + version
                    + " (supported: 5-7). Re-save the schematic with a current Litematica.");
        }
        int dataVersion = Nbt.intVal(root, "MinecraftDataVersion", -1);
        Map<String, Object> meta = Nbt.compound(root, "Metadata");
        String name = meta != null ? Nbt.string(meta, "Name", fallbackName) : fallbackName;
        if (name.isBlank()) name = fallbackName;

        Map<String, Object> regions = Nbt.compound(root, "Regions");
        if (regions == null || regions.isEmpty()) throw new SchematicFormatException("Schematic has no regions");

        // Pass 1: geometry
        record Geo(Map<String, Object> region, int minX, int minY, int minZ, int sx, int sy, int sz) {}
        List<Geo> geos = new ArrayList<>();
        int gMinX = Integer.MAX_VALUE, gMinY = Integer.MAX_VALUE, gMinZ = Integer.MAX_VALUE;
        int gMaxX = Integer.MIN_VALUE, gMaxY = Integer.MIN_VALUE, gMaxZ = Integer.MIN_VALUE;
        for (Map.Entry<String, Object> e : regions.entrySet()) {
            if (!(e.getValue() instanceof Map)) continue;
            @SuppressWarnings("unchecked") Map<String, Object> r = (Map<String, Object>) e.getValue();
            Map<String, Object> pos = Nbt.compound(r, "Position");
            Map<String, Object> size = Nbt.compound(r, "Size");
            if (pos == null || size == null) throw new SchematicFormatException("Region '" + e.getKey() + "' lacks Position/Size");
            int px = Nbt.intVal(pos, "x", 0), py = Nbt.intVal(pos, "y", 0), pz = Nbt.intVal(pos, "z", 0);
            int rx = Nbt.intVal(size, "x", 0), ry = Nbt.intVal(size, "y", 0), rz = Nbt.intVal(size, "z", 0);
            if (rx == 0 || ry == 0 || rz == 0) continue; // empty region
            int ax = Math.abs(rx), ay = Math.abs(ry), az = Math.abs(rz);
            int minX = rx < 0 ? px + rx + 1 : px;
            int minY = ry < 0 ? py + ry + 1 : py;
            int minZ = rz < 0 ? pz + rz + 1 : pz;
            geos.add(new Geo(r, minX, minY, minZ, ax, ay, az));
            gMinX = Math.min(gMinX, minX); gMinY = Math.min(gMinY, minY); gMinZ = Math.min(gMinZ, minZ);
            gMaxX = Math.max(gMaxX, minX + ax - 1); gMaxY = Math.max(gMaxY, minY + ay - 1); gMaxZ = Math.max(gMaxZ, minZ + az - 1);
        }
        if (geos.isEmpty()) throw new SchematicFormatException("All regions are empty");

        long tx = (long) gMaxX - gMinX + 1, ty = (long) gMaxY - gMinY + 1, tz = (long) gMaxZ - gMinZ + 1;
        if (tx * ty * tz > MAX_CELLS) {
            throw new SchematicFormatException("Schematic bounding box " + tx + "x" + ty + "x" + tz
                    + " exceeds the supported maximum of " + MAX_CELLS + " cells");
        }
        int sx = (int) tx, sy = (int) ty, sz = (int) tz;

        // Pass 2: decode
        Map<BlockStateKey, Integer> global = new LinkedHashMap<>();
        global.put(BlockStateKey.AIR, 0);
        int[] out = new int[sx * sy * sz]; // zero-filled == minecraft:air

        for (Geo g : geos) {
            List<Object> pal = Nbt.list(g.region, "BlockStatePalette");
            long[] bits = Nbt.longArray(g.region, "BlockStates");
            if (pal == null || pal.isEmpty()) throw new SchematicFormatException("Region without BlockStatePalette");
            if (bits == null) throw new SchematicFormatException("Region without BlockStates");

            int[] remap = new int[pal.size()];
            for (int i = 0; i < pal.size(); i++) {
                BlockStateKey k = paletteEntry(pal.get(i));
                remap[i] = global.computeIfAbsent(k, kk -> global.size());
            }

            int bpe = Math.max(2, 32 - Integer.numberOfLeadingZeros(pal.size() - 1));
            long volume = (long) g.sx * g.sy * g.sz;
            long needed = (volume * bpe + 63) / 64;
            if (bits.length < needed) {
                throw new SchematicFormatException("BlockStates array too short: " + bits.length + " longs, need " + needed);
            }
            long mask = (1L << bpe) - 1L;
            int offX = g.minX - gMinX, offY = g.minY - gMinY, offZ = g.minZ - gMinZ;

            for (int y = 0; y < g.sy; y++) {
                for (int z = 0; z < g.sz; z++) {
                    for (int x = 0; x < g.sx; x++) {
                        long i = ((long) y * g.sz + z) * g.sx + x;
                        int v = (int) getPacked(bits, i, bpe, mask);
                        if (v >= remap.length) {
                            throw new SchematicFormatException("Palette index " + v + " out of range (palette size "
                                    + remap.length + ") at region cell " + x + "," + y + "," + z);
                        }
                        out[((offY + y) * sz + (offZ + z)) * sx + (offX + x)] = remap[v];
                    }
                }
            }
        }
        return new Schematic(name, dataVersion, sx, sy, sz, global.keySet().toArray(new BlockStateKey[0]), out);
    }

    static long getPacked(long[] arr, long index, int bits, long mask) {
        long startOffset = index * bits;
        int startArr = (int) (startOffset >>> 6);
        int endArr = (int) (((index + 1) * bits - 1) >>> 6);
        int startBit = (int) (startOffset & 63L);
        if (startArr == endArr) return (arr[startArr] >>> startBit) & mask;
        int endOffset = 64 - startBit;
        return ((arr[startArr] >>> startBit) | (arr[endArr] << endOffset)) & mask;
    }

    @SuppressWarnings("unchecked")
    private static BlockStateKey paletteEntry(Object o) throws SchematicFormatException {
        if (!(o instanceof Map)) throw new SchematicFormatException("Palette entry is not a compound");
        Map<String, Object> m = (Map<String, Object>) o;
        String n = Nbt.string(m, "Name", null);
        if (n == null) throw new SchematicFormatException("Palette entry without Name");
        Map<String, String> props = new TreeMap<>();
        Map<String, Object> pc = Nbt.compound(m, "Properties");
        if (pc != null) for (Map.Entry<String, Object> e : pc.entrySet()) props.put(e.getKey(), String.valueOf(e.getValue()));
        return BlockStateKey.of(n, props);
    }
}
