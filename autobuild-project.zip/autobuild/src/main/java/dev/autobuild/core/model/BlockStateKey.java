package dev.autobuild.core.model;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;

public class BlockStateKey {
    private final String name;
    private final Map<String, String> properties;

    public BlockStateKey(String name, Map<String, String> properties) {
        this.name = name;
        this.properties = properties != null ? Collections.unmodifiableMap(properties) : Collections.emptyMap();
    }

    public String getName() { return name; }
    public Map<String, String> getProperties() { return properties; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BlockStateKey)) return false;
        BlockStateKey that = (BlockStateKey) o;
        return name.equals(that.name) && properties.equals(that.properties);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, properties);
    }

    @Override
    public String toString() {
        return properties.isEmpty() ? name : name + properties.toString();
    }
}
