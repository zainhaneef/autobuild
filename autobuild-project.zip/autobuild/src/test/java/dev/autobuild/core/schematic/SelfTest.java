package dev.autobuild.core.schematic;

import dev.autobuild.core.model.PlacedSchematic;
import dev.autobuild.core.model.Pos;
import dev.autobuild.core.model.Transform;
import dev.autobuild.core.compare.WorldComparator;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class SelfTest {

    @Test
    public void testSchematicCreationAndSummary() {
        Schematic sch = TestStructures.createTestHouse();
        assertNotNull(sch);
        assertEquals("TestHouse", sch.getName());
        assertEquals(27, sch.getTotalBlocks());

        SchematicSummary summary = new SchematicSummary(sch);
        assertEquals(27, summary.getTotalBlocks());
    }

    @Test
    public void testLitematicReadWrite() throws Exception {
        Schematic original = TestStructures.createTestHouse();
        File tempFile = File.createTempFile("test_house", ".litematic");
        tempFile.deleteOnExit();

        LitematicWriter.write(original, tempFile);
        assertTrue(tempFile.exists());

        Schematic loaded = LitematicReader.read(tempFile);
        assertNotNull(loaded);
        assertEquals(original.getName(), loaded.getName());
        assertEquals(original.getTotalBlocks(), loaded.getTotalBlocks());
    }

    @Test
    public void testWorldComparator() {
        Schematic sch = TestStructures.createTestHouse();
        PlacedSchematic placed = new PlacedSchematic(sch, new Pos(0, 64, 0), Transform.NONE);
        List<WorldComparator.Difference> diffs = WorldComparator.compareSchematic(placed);
        assertFalse(diffs.isEmpty());
    }

    @Test
    public void testBuilderState() {
        Schematic sch = TestStructures.createTestHouse();
        PlacedSchematic placed = new PlacedSchematic(sch, new Pos(0, 0, 0), Transform.NONE);
        SchematicBuilder builder = new SchematicBuilder();
        builder.load(placed);
        assertEquals(27, builder.getTotalBlocks());
        assertFalse(builder.isRunning());

        builder.start();
        assertTrue(builder.isRunning());
        builder.pause();
        assertTrue(builder.isPaused());
        builder.resume();
        assertFalse(builder.isPaused());
        builder.stop();
        assertFalse(builder.isRunning());
    }
}
