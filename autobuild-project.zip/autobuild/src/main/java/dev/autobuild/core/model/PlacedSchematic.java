package dev.autobuild.core.model;

import dev.autobuild.core.schematic.Schematic;

public class PlacedSchematic {
    private final Schematic schematic;
    private Pos origin;
    private Transform transform;

    public PlacedSchematic(Schematic schematic, Pos origin, Transform transform) {
        this.schematic = schematic;
        this.origin = origin;
        this.transform = transform != null ? transform : Transform.NONE;
    }

    public Schematic getSchematic() { return schematic; }
    public Pos getOrigin() { return origin; }
    public void setOrigin(Pos origin) { this.origin = origin; }
    public Transform getTransform() { return transform; }
    public void setTransform(Transform transform) { this.transform = transform; }
}
