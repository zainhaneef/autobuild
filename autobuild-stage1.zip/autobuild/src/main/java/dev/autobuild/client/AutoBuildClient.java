package dev.autobuild.client;

import com.mojang.brigadier.arguments.StringArgumentType;
import dev.autobuild.core.schematic.LitematicReader;
import dev.autobuild.core.schematic.LitematicWriter;
import dev.autobuild.core.schematic.Schematic;
import dev.autobuild.core.schematic.SchematicSummary;
import dev.autobuild.core.schematic.TestStructures;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Stage 1 entrypoint: registers /autobuild inspect and /autobuild exporttest.
 * Later stages add the planner, movement, GUI and keybind here.
 */
public class AutoBuildClient implements ClientModInitializer {
    public static final String MOD_ID = "autobuild";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("autobuild")
                        .then(ClientCommandManager.literal("inspect")
                                .then(ClientCommandManager.argument("file", StringArgumentType.greedyString())
                                        .executes(ctx -> inspect(ctx.getSource(), StringArgumentType.getString(ctx, "file")))))
                        .then(ClientCommandManager.literal("exporttest")
                                .executes(ctx -> exportTest(ctx.getSource())))));
        LOG.info("AutoBuild (stage 1) loaded");
    }

    /** Same folder Litematica uses: .minecraft/schematics */
    static Path schematicsDir() {
        return FabricLoader.getInstance().getGameDir().resolve("schematics").toAbsolutePath().normalize();
    }

    private static void feedback(FabricClientCommandSource src, String msg) {
        MinecraftClient.getInstance().execute(() -> src.sendFeedback(Text.literal(msg)));
    }

    private static void error(FabricClientCommandSource src, String msg) {
        MinecraftClient.getInstance().execute(() -> src.sendError(Text.literal(msg)));
    }

    private static int inspect(FabricClientCommandSource src, String fileName) {
        Path dir = schematicsDir();
        Path file = dir.resolve(fileName).normalize();
        if (!file.startsWith(dir)) {
            error(src, "File must be inside " + dir);
            return 0;
        }
        feedback(src, "Loading " + file.getFileName() + " ...");
        // Parse off the render thread so large schematics never freeze the client.
        Thread t = new Thread(() -> {
            try {
                Schematic s = LitematicReader.read(file);
                List<String> lines = SchematicSummary.describe(s, 12);
                for (String l : lines) feedback(src, l);
                LOG.info("Inspected {}: {}x{}x{}, {} blocks", file.getFileName(), s.sizeX, s.sizeY, s.sizeZ, s.countNonAir());
            } catch (Exception e) {
                LOG.error("Failed to read schematic {}", file, e);
                error(src, "Could not read schematic: " + e.getMessage());
            }
        }, "autobuild-loader");
        t.setDaemon(true);
        t.start();
        return 1;
    }

    private static int exportTest(FabricClientCommandSource src) {
        try {
            Path dir = schematicsDir();
            Files.createDirectories(dir);
            Path out = dir.resolve("autobuild_test_house.litematic");
            LitematicWriter.write(TestStructures.smallHouse(), out, "AutoBuild");
            feedback(src, "Wrote " + out);
            return 1;
        } catch (Exception e) {
            LOG.error("Export failed", e);
            error(src, "Export failed: " + e.getMessage());
            return 0;
        }
    }
}
