# AutoBuild Pro — Complete Fabric 1.21.4 Schematic Builder

Professional Fabric client-side mod for automated construction from Litematica `.litematic` schematics in Minecraft Java Edition 1.21.4.

## Windows Installation Guide
1. Ensure **Java 21** and **Fabric Loader 1.21.4** are installed.
2. Build the mod JAR using Gradle.
3. Move the generated JAR file (`build/libs/autobuild-1.0.0.jar`) into your Minecraft `mods` folder (`%appdata%\.minecraft\mods`).
4. Launch Minecraft with the Fabric profile.

## Build Instructions (CMD)
Open Command Prompt in the project root directory and run:
```cmd
gradlew build
```
The installable mod JAR will be located at:
`build/libs/autobuild-1.0.0.jar`
