package dev.autobuild.core.schematic;

import dev.autobuild.core.model.BlockStateKey;

import java.util.*;

/** Convenience builder for creating schematics in code (tests, sample structures). */
public final class SchematicBuilder {
    private final String name;
    private final int dataVersion, sx, sy, sz;
    private final Map<BlockStateKey, Integer> palette = new LinkedHashMap<>();
    private final int[] blocks;

    public SchematicBuilder(String name, int dataVersion, int sx, int sy, int sz) {
        this.name = name;
        this.dataVersion = dataVersion;
        this.sx = sx;
        this.sy = sy;
        this.sz = sz;
        this.blocks = new int[sx * sy * sz];
        palette.put(BlockStateKey.AIR, 0);
    }

    public SchematicBuilder set(int x, int y, int z, String state) {
        if (x < 0 || y < 0 || z < 0 || x >= sx || y >= sy || z >= sz)
            throw new IllegalArgumentException("Out of bounds: " + x + "," + y + "," + z);
        BlockStateKey k = BlockStateKey.parse(state);
        int idx = palette.computeIfAbsent(k, kk -> palette.size());
        blocks[(y * sz + z) * sx + x] = idx;
        return this;
    }

    /** Inclusive fill. */
    public SchematicBuilder fill(int x1, int y1, int z1, int x2, int y2, int z2, String state) {
        for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
            for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++)
                for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
                    set(x, y, z, state);
        return this;
    }

    public Schematic build() {
        return new Schematic(name, dataVersion, sx, sy, sz, palette.keySet().toArray(new BlockStateKey[0]), blocks.clone());
    }
}
