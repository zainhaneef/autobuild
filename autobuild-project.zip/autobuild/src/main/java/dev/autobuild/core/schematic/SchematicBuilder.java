package dev.autobuild.core.schematic;

import dev.autobuild.core.model.PlacedSchematic;
import java.util.*;

public class SchematicBuilder {
    private PlacedSchematic placedSchematic;
    private boolean running = false, paused = false;
    private int totalBlocks = 0, completedBlocks = 0;
    private String speedPreset = "Normal";
    private final List<String> errorLog = new ArrayList<>();

    public void load(PlacedSchematic placed) {
        this.placedSchematic = placed;
        if (placed != null) this.totalBlocks = placed.getSchematic().getTotalBlocks();
        this.completedBlocks = 0;
        this.running = false;
        this.paused = false;
    }

    public void start() { if (placedSchematic != null) { running = true; paused = false; } }
    public void pause() { if (running) paused = true; }
    public void resume() { if (running && paused) paused = false; }
    public void stop() { running = false; paused = false; }

    public boolean isRunning() { return running; }
    public boolean isPaused() { return paused; }
    public int getTotalBlocks() { return totalBlocks; }
    public int getCompletedBlocks() { return completedBlocks; }
    public void setCompletedBlocks(int val) { this.completedBlocks = val; }
    public String getSpeedPreset() { return speedPreset; }
    public void setSpeedPreset(String speedPreset) { this.speedPreset = speedPreset; }
    public List<String> getErrorLog() { return errorLog; }
}
