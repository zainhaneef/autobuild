package dev.autobuild.core.schematic;

import java.util.Map;

public class SchematicSummary {
    private final String name;
    private final int totalBlocks, uniqueBlockTypes;
    private final Map<String, Integer> materialRequirements;

    public SchematicSummary(Schematic schematic) {
        this.name = schematic.getName();
        this.totalBlocks = schematic.getTotalBlocks();
        this.materialRequirements = schematic.getMaterialRequirements();
        this.uniqueBlockTypes = materialRequirements.size();
    }

    public String getName() { return name; }
    public int getTotalBlocks() { return totalBlocks; }
    public int getUniqueBlockTypes() { return uniqueBlockTypes; }
    public Map<String, Integer> getMaterialRequirements() { return materialRequirements; }
}
