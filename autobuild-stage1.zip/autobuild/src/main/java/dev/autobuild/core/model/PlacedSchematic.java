package dev.autobuild.core.model;

import dev.autobuild.core.schematic.Schematic;

/**
 * A schematic (already rotated/mirrored) anchored in the world.
 * The anchor is the MINIMUM corner (lowest x, y, z) of the schematic's bounding box.
 */
public final class PlacedSchematic {
    public final Schematic schematic;
    public final Pos origin;

    public PlacedSchematic(Schematic schematic, Pos origin) {
        this.schematic = schematic;
        this.origin = origin;
    }

    public static PlacedSchematic of(Schematic source, Transform transform, Pos origin) {
        return new PlacedSchematic(source.transformed(transform), origin);
    }

    public Pos worldPos(int index) {
        Pos p = schematic.posOfIndex(index);
        return new Pos(origin.x() + p.x(), origin.y() + p.y(), origin.z() + p.z());
    }

    public BlockStateKey expected(int index) { return schematic.stateAtIndex(index); }

    /** Cell index for a world position, or -1 when outside the schematic's box. */
    public int indexOf(Pos world) {
        int x = world.x() - origin.x(), y = world.y() - origin.y(), z = world.z() - origin.z();
        return schematic.inBounds(x, y, z) ? schematic.index(x, y, z) : -1;
    }

    public Pos max() {
        return new Pos(origin.x() + schematic.sizeX - 1, origin.y() + schematic.sizeY - 1, origin.z() + schematic.sizeZ - 1);
    }
}
