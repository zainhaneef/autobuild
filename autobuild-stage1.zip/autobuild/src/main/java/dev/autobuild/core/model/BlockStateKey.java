package dev.autobuild.core.model;

import java.util.*;

/**
 * Canonical, immutable block state: namespaced name + sorted properties.
 * String form matches vanilla: {@code minecraft:oak_stairs[facing=north,half=bottom]}.
 */
public final class BlockStateKey {
    public static final BlockStateKey AIR = new BlockStateKey("minecraft:air", Map.of());

    private final String name;
    private final SortedMap<String, String> props;
    private final String text;

    private BlockStateKey(String name, Map<String, String> props) {
        this.name = name;
        this.props = Collections.unmodifiableSortedMap(new TreeMap<>(props));
        StringBuilder sb = new StringBuilder(name);
        if (!this.props.isEmpty()) {
            sb.append('[');
            boolean first = true;
            for (Map.Entry<String, String> e : this.props.entrySet()) {
                if (!first) sb.append(',');
                sb.append(e.getKey()).append('=').append(e.getValue());
                first = false;
            }
            sb.append(']');
        }
        this.text = sb.toString();
    }

    public static BlockStateKey of(String name, Map<String, String> props) {
        return new BlockStateKey(normalizeName(name), props == null ? Map.of() : props);
    }

    public static BlockStateKey parse(String s) {
        s = s.trim();
        int br = s.indexOf('[');
        if (br < 0) return of(s, null);
        if (!s.endsWith("]")) throw new IllegalArgumentException("Bad block state: " + s);
        Map<String, String> p = new TreeMap<>();
        String body = s.substring(br + 1, s.length() - 1);
        if (!body.isBlank()) {
            for (String kv : body.split(",")) {
                int eq = kv.indexOf('=');
                if (eq <= 0) throw new IllegalArgumentException("Bad property '" + kv + "' in " + s);
                p.put(kv.substring(0, eq).trim(), kv.substring(eq + 1).trim());
            }
        }
        return of(s.substring(0, br), p);
    }

    private static String normalizeName(String n) {
        return n.indexOf(':') < 0 ? "minecraft:" + n : n;
    }

    public String name() { return name; }
    public SortedMap<String, String> properties() { return props; }
    public String get(String prop) { return props.get(prop); }
    public boolean has(String prop) { return props.containsKey(prop); }

    public boolean isAir() {
        return name.equals("minecraft:air") || name.equals("minecraft:cave_air") || name.equals("minecraft:void_air");
    }

    public BlockStateKey withProperties(Map<String, String> newProps) { return new BlockStateKey(name, newProps); }

    public BlockStateKey with(String prop, String value) {
        Map<String, String> m = new TreeMap<>(props);
        m.put(prop, value);
        return new BlockStateKey(name, m);
    }

    @Override public boolean equals(Object o) { return o instanceof BlockStateKey b && b.text.equals(text); }
    @Override public int hashCode() { return text.hashCode(); }
    @Override public String toString() { return text; }
}
