package dev.autobuild.core.compare;

import dev.autobuild.core.model.BlockStateKey;

import java.util.Map;
import java.util.Set;

/**
 * Decides whether an actual world state satisfies an expected schematic state.
 * <p>EXACT compares every property. PLACEMENT ignores properties that the game derives from
 * neighbours or runtime activity after placement (fence/wall connections, stair shape, redstone
 * power, leaf distance, ...) because a builder cannot choose them directly. Use EXACT for the final
 * verification report and PLACEMENT to decide whether a cell still needs work.
 */
public final class StateMatcher {
    private StateMatcher() {}

    public enum Mode { EXACT, PLACEMENT }

    /** Properties that are computed by the game rather than chosen by the placing player. */
    public static final Set<String> DERIVED_PROPERTIES = Set.of(
            "north", "east", "south", "west", "up", "down",   // connections (fences, panes, walls, vines, wire)
            "shape",                                          // stairs and rails
            "distance", "persistent_ignored",                 // leaves distance (persistent is NOT ignored)
            "power", "powered", "triggered", "locked",        // redstone-driven
            "snowy", "bottom", "tilt", "occupied", "unstable", "attached", "disarmed"
    );

    public static boolean matches(BlockStateKey expected, BlockStateKey actual, Mode mode) {
        if (actual == null) return false;
        if (expected.isAir()) return actual.isAir();
        if (!expected.name().equals(actual.name())) return false;
        for (Map.Entry<String, String> e : expected.properties().entrySet()) {
            if (mode == Mode.PLACEMENT && DERIVED_PROPERTIES.contains(e.getKey())) continue;
            String a = actual.get(e.getKey());
            if (!e.getValue().equals(a)) return false;
        }
        return true;
    }
}
