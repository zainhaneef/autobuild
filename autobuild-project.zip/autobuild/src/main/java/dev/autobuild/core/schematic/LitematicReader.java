package dev.autobuild.core.schematic;

import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.model.Pos;
import dev.autobuild.core.nbt.Nbt;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class LitematicReader {
    public static Schematic read(File file) throws IOException {
        Nbt.CompoundTag root = Nbt.readCompressed(file);
        return parse(root, file.getName());
    }

    public static Schematic parse(Nbt.CompoundTag root, String fallbackName) {
        String name = fallbackName;
        Nbt.CompoundTag metadata = root.getCompound("Metadata");
        if (metadata != null && !metadata.getString("Name").isEmpty()) {
            name = metadata.getString("Name");
        }

        Map<String, Schematic.Region> regionMap = new HashMap<>();
        Nbt.CompoundTag regions = root.getCompound("Regions");
        if (regions != null) {
            for (Map.Entry<String, Object> entry : regions.getMap().entrySet()) {
                if (entry.getValue() instanceof Nbt.CompoundTag) {
                    regionMap.put(entry.getKey(), parseRegion(entry.getKey(), (Nbt.CompoundTag) entry.getValue()));
                }
            }
        }
        return new Schematic(name, regionMap);
    }

    private static Schematic.Region parseRegion(String name, Nbt.CompoundTag tag) {
        Nbt.CompoundTag p = tag.getCompound("Position");
        Pos pos = new Pos(p.getInt("x"), p.getInt("y"), p.getInt("z"));

        Nbt.CompoundTag s = tag.getCompound("Size");
        Pos size = new Pos(Math.max(1, s.getInt("x")), Math.max(1, s.getInt("y")), Math.max(1, s.getInt("z")));

        List<BlockStateKey> palette = new ArrayList<>();
        List<Object> paletteTag = tag.getList("BlockStatePalette");
        if (paletteTag != null) {
            for (Object obj : paletteTag) {
                if (obj instanceof Nbt.CompoundTag) {
                    Nbt.CompoundTag st = (Nbt.CompoundTag) obj;
                    Map<String, String> props = new HashMap<>();
                    Nbt.CompoundTag pt = st.getCompound("Properties");
                    if (pt != null) {
                        for (Map.Entry<String, Object> pe : pt.getMap().entrySet()) {
                            props.put(pe.getKey(), String.valueOf(pe.getValue()));
                        }
                    }
                    palette.add(new BlockStateKey(st.getString("Name"), props));
                }
            }
        }
        if (palette.isEmpty()) palette.add(new BlockStateKey("minecraft:air", Collections.emptyMap()));

        long[] longArray = tag.get("BlockStates") instanceof long[] ? (long[]) tag.get("BlockStates") : null;
        int[] blockStates = unpackBlockStates(longArray, size.x * size.y * size.z, palette.size());

        return new Schematic.Region(name, pos, size, palette, blockStates);
    }

    private static int[] unpackBlockStates(long[] longs, int totalBlocks, int paletteSize) {
        int[] states = new int[totalBlocks];
        if (longs == null || longs.length == 0) return states;

        int bitsPerEntry = Math.max(2, 32 - Integer.numberOfLeadingZeros(paletteSize - 1));
        if (bitsPerEntry < 4) bitsPerEntry = 4;
        int entriesPerLong = 64 / bitsPerEntry;

        for (int i = 0; i < totalBlocks; i++) {
            int longIndex = i / entriesPerLong;
            int bitIndex = (i % entriesPerLong) * bitsPerEntry;
            if (longIndex < longs.length) {
                states[i] = (int) ((longs[longIndex] >>> bitIndex) & ((1L << bitsPerEntry) - 1));
            }
        }
        return states;
    }
}
