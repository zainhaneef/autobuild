package dev.autobuild.core.schematic;

import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.model.Pos;

import java.util.*;

public class TestStructures {
    public static Schematic createTestHouse() {
        List<BlockStateKey> palette = Arrays.asList(
            new BlockStateKey("minecraft:air", Collections.emptyMap()),
            new BlockStateKey("minecraft:oak_log", Collections.emptyMap()),
            new BlockStateKey("minecraft:oak_planks", Collections.emptyMap())
        );

        Pos size = new Pos(3, 3, 3);
        int[] states = new int[27];
        Arrays.fill(states, 2); // default planks

        Schematic.Region region = new Schematic.Region("main", new Pos(0, 64, 0), size, palette, states);
        Map<String, Schematic.Region> regions = new HashMap<>();
        regions.put("main", region);
        return new Schematic("TestHouse", regions);
    }
}
