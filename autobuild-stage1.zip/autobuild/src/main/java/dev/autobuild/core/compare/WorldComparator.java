package dev.autobuild.core.compare;

import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.model.PlacedSchematic;
import dev.autobuild.core.model.Pos;

import java.util.Arrays;

/**
 * Compares a {@link PlacedSchematic} against the real world through a {@link WorldView}.
 * Never treats "occupied" as "correct": every cell is compared by block state.
 */
public final class WorldComparator {
    private WorldComparator() {}

    /** Read-only view of the world. Returns null when the position is not loaded/readable. */
    public interface WorldView {
        BlockStateKey getBlockState(Pos pos);
    }

    public enum Status {
        /** Expected non-air and the world matches. */
        MATCH,
        /** Expected non-air, world has air: needs placing. */
        MISSING,
        /** Expected non-air, world has a different non-air state: needs fixing (break/replace). */
        INCORRECT,
        /** Expected air (schematic wants empty) but the world has a block: needs clearing. */
        EXTRA,
        /** Expected air and world is air. */
        CLEAR,
        /** Chunk not loaded / unreadable. */
        UNKNOWN
    }

    /** Tiny growable int list to avoid boxing on large schematics. */
    public static final class IntList {
        private int[] a = new int[16];
        private int n;
        public void add(int v) { if (n == a.length) a = Arrays.copyOf(a, n * 2); a[n++] = v; }
        public int size() { return n; }
        public int get(int i) { return a[i]; }
        public int[] toArray() { return Arrays.copyOf(a, n); }
    }

    public static final class Report {
        public int match, missing, incorrect, extra, clear, unknown;
        public final IntList missingCells = new IntList();
        public final IntList incorrectCells = new IntList();
        public final IntList extraCells = new IntList();
        public final IntList unknownCells = new IntList();

        /** Non-air cells in the schematic that are finished. */
        public int done() { return match; }
        public int totalTargets() { return match + missing + incorrect + unknown; }
        public double percentComplete() {
            int t = totalTargets();
            return t == 0 ? 100.0 : 100.0 * match / t;
        }
        public boolean perfect() { return missing == 0 && incorrect == 0 && extra == 0 && unknown == 0; }

        @Override public String toString() {
            return String.format("match=%d missing=%d incorrect=%d extra=%d unknown=%d (%.1f%%)",
                    match, missing, incorrect, extra, unknown, percentComplete());
        }
    }

    public static Status classify(BlockStateKey expected, BlockStateKey actual, StateMatcher.Mode mode) {
        if (actual == null) return Status.UNKNOWN;
        if (expected.isAir()) return actual.isAir() ? Status.CLEAR : Status.EXTRA;
        if (actual.isAir()) return Status.MISSING;
        return StateMatcher.matches(expected, actual, mode) ? Status.MATCH : Status.INCORRECT;
    }

    /** Compares the whole schematic. Prefer {@link #compareRange} when called from a game tick. */
    public static Report compare(PlacedSchematic placed, WorldView world, StateMatcher.Mode mode) {
        Report r = new Report();
        compareRange(placed, world, mode, 0, placed.schematic.volume(), r);
        return r;
    }

    /**
     * Compares cells [from, to) and accumulates into {@code into}. Call repeatedly with a small batch
     * size (for example a few thousand cells per tick) so the client never stalls.
     * Returns the next index to continue from.
     */
    public static int compareRange(PlacedSchematic placed, WorldView world, StateMatcher.Mode mode,
                                   int from, int to, Report into) {
        int end = Math.min(to, placed.schematic.volume());
        for (int i = from; i < end; i++) {
            BlockStateKey expected = placed.expected(i);
            // Skip the world lookup for expected-air cells only if the caller does not care about EXTRA.
            Status s = classify(expected, world.getBlockState(placed.worldPos(i)), mode);
            switch (s) {
                case MATCH -> into.match++;
                case MISSING -> { into.missing++; into.missingCells.add(i); }
                case INCORRECT -> { into.incorrect++; into.incorrectCells.add(i); }
                case EXTRA -> { into.extra++; into.extraCells.add(i); }
                case CLEAR -> into.clear++;
                case UNKNOWN -> { into.unknown++; into.unknownCells.add(i); }
            }
        }
        return end;
    }
}
