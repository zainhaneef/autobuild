package dev.autobuild.client;

import com.mojang.brigadier.arguments.StringArgumentType;
import dev.autobuild.core.model.PlacedSchematic;
import dev.autobuild.core.model.Pos;
import dev.autobuild.core.model.Transform;
import dev.autobuild.core.schematic.Schematic;
import dev.autobuild.core.schematic.SchematicBuilder;
import dev.autobuild.core.schematic.TestStructures;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.io.File;

public class AutoBuildClient implements ClientModInitializer {
    private static Schematic currentSchematic;
    private static PlacedSchematic placedSchematic;
    private static final SchematicBuilder builder = new SchematicBuilder();

    @Override
    public void onInitializeClient() {
        currentSchematic = TestStructures.createTestHouse();
        placedSchematic = new PlacedSchematic(currentSchematic, new Pos(0, 64, 0), Transform.NONE);
        builder.load(placedSchematic);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("autobuild")
                .executes(context -> {
                    sendMessage(context.getSource().getClient(), "§a[AutoBuild Pro] §eActive Schematic: §f" + currentSchematic.getName() + " §e| Blocks: §f" + builder.getTotalBlocks());
                    return 1;
                })
                .then(ClientCommandManager.literal("help").executes(context -> {
                    MinecraftClient c = context.getSource().getClient();
                    sendMessage(c, "§6=== AutoBuild Pro Commands ===");
                    sendMessage(c, "§e/autobuild start §7- Start build");
                    sendMessage(c, "§e/autobuild pause §7- Pause build");
                    sendMessage(c, "§e/autobuild resume §7- Resume build");
                    sendMessage(c, "§e/autobuild stop §7- Stop build");
                    sendMessage(c, "§e/autobuild status §7- Show status");
                    sendMessage(c, "§e/autobuild list §7- List schematics");
                    return 1;
                }))
                .then(ClientCommandManager.literal("list").executes(context -> {
                    MinecraftClient c = context.getSource().getClient();
                    File dir = new File(c.runDirectory, "schematics");
                    if (!dir.exists()) dir.mkdirs();
                    File[] files = dir.listFiles((d, name) -> name.endsWith(".litematic"));
                    sendMessage(c, "§6=== Schematics (" + dir.getAbsolutePath() + ") ===");
                    if (files == null || files.length == 0) sendMessage(c, "§7No .litematic files found. Default test house active.");
                    else for (File f : files) sendMessage(c, "§f- " + f.getName());
                    return 1;
                }))
                .then(ClientCommandManager.literal("start").executes(context -> { builder.start(); sendMessage(context.getSource().getClient(), "§a[AutoBuild] Build started."); return 1; }))
                .then(ClientCommandManager.literal("pause").executes(context -> { builder.pause(); sendMessage(context.getSource().getClient(), "§e[AutoBuild] Build paused."); return 1; }))
                .then(ClientCommandManager.literal("resume").executes(context -> { builder.resume(); sendMessage(context.getSource().getClient(), "§a[AutoBuild] Build resumed."); return 1; }))
                .then(ClientCommandManager.literal("stop").executes(context -> { builder.stop(); sendMessage(context.getSource().getClient(), "§c[AutoBuild] Build stopped."); return 1; }))
                .then(ClientCommandManager.literal("status").executes(context -> {
                    MinecraftClient c = context.getSource().getClient();
                    sendMessage(c, "§6=== Status ===");
                    sendMessage(c, "§eRunning: §f" + builder.isRunning() + " §e| Progress: §f" + builder.getCompletedBlocks() + "/" + builder.getTotalBlocks());
                    return 1;
                }))
                .then(ClientCommandManager.literal("speed").then(ClientCommandManager.argument("preset", StringArgumentType.word())
                    .executes(context -> {
                        String preset = StringArgumentType.getString(context, "preset");
                        builder.setSpeedPreset(preset);
                        sendMessage(context.getSource().getClient(), "§a[AutoBuild] Speed set to " + preset);
                        return 1;
                    })))
            );
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (builder.isRunning() && !builder.isPaused()) {
                if (client.world != null && client.world.getTime() % 20 == 0) {
                    if (builder.getCompletedBlocks() < builder.getTotalBlocks()) {
                        builder.setCompletedBlocks(builder.getCompletedBlocks() + 1);
                    }
                }
            }
        });
    }

    private static void sendMessage(MinecraftClient client, String msg) {
        if (client.player != null) client.player.sendMessage(Text.literal(msg), false);
    }
}
