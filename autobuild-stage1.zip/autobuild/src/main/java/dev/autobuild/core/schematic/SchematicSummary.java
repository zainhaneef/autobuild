package dev.autobuild.core.schematic;

import dev.autobuild.core.model.BlockStateKey;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Human-readable schematic summary, shared by the in-game command and the command-line inspector. */
public final class SchematicSummary {
    private SchematicSummary() {}

    public static List<String> describe(Schematic s, int topN) {
        List<String> lines = new ArrayList<>();
        lines.add("Name: " + s.name + "  (data version " + s.dataVersion + ")");
        lines.add("Size: " + s.sizeX + " x " + s.sizeY + " x " + s.sizeZ + "  (" + s.volume() + " cells)");
        lines.add("Non-air blocks: " + s.countNonAir() + ", palette entries: " + s.palette.length);
        int shown = 0;
        for (Map.Entry<BlockStateKey, Integer> e : s.materialCounts()) {
            if (shown++ >= topN) { lines.add("  ..."); break; }
            lines.add("  " + e.getValue() + " x " + e.getKey());
        }
        return lines;
    }

    /** Usage: Inspect &lt;file.litematic&gt; [rotationSteps] [none|left_right|front_back] */
    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("Usage: SchematicSummary <file.litematic> [rotationSteps 0-3] [mirror none|left_right|front_back]");
            System.exit(2);
        }
        Schematic s = LitematicReader.read(Path.of(args[0]));
        if (args.length > 1) {
            int steps = Integer.parseInt(args[1]);
            var mirror = args.length > 2
                    ? dev.autobuild.core.model.Transform.Mirror.valueOf(args[2].toUpperCase())
                    : dev.autobuild.core.model.Transform.Mirror.NONE;
            s = s.transformed(new dev.autobuild.core.model.Transform(steps, mirror));
        }
        for (String l : describe(s, 40)) System.out.println(l);
    }
}
