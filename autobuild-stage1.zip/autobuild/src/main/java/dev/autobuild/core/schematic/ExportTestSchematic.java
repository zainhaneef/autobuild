package dev.autobuild.core.schematic;

import java.nio.file.Files;
import java.nio.file.Path;

/** Usage: ExportTestSchematic &lt;output.litematic&gt; */
public final class ExportTestSchematic {
    private ExportTestSchematic() {}

    public static void main(String[] args) throws Exception {
        Path out = Path.of(args.length > 0 ? args[0] : "autobuild_test_house.litematic");
        if (out.getParent() != null) Files.createDirectories(out.getParent());
        LitematicWriter.write(TestStructures.smallHouse(), out, "AutoBuild");
        System.out.println("Wrote " + out.toAbsolutePath());
    }
}
