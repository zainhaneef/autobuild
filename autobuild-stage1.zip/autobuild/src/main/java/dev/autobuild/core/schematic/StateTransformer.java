package dev.autobuild.core.schematic;

import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.model.Transform;

import java.util.Map;
import java.util.TreeMap;

/**
 * Applies a {@link Transform} to block state properties (facing, axis, rotation, side connections,
 * stair/rail shape, hinge, chest type). Properties this class does not know are left untouched;
 * see KNOWN LIMITS in the README for blocks that need extra handling.
 */
public final class StateTransformer {
    private StateTransformer() {}

    private static final String[] SIDES = {"north", "east", "south", "west"};

    public static BlockStateKey transform(BlockStateKey in, Transform t) {
        if (t.isIdentity() || in.properties().isEmpty()) return in;
        Map<String, String> p = new TreeMap<>(in.properties());
        String name = in.name();
        boolean mirrored = t.mirror() != Transform.Mirror.NONE;

        if (p.containsKey("facing")) p.put("facing", t.dir(p.get("facing")));

        if (p.containsKey("axis") && (t.rotationSteps() & 1) == 1) {
            String a = p.get("axis");
            if (a.equals("x")) p.put("axis", "z"); else if (a.equals("z")) p.put("axis", "x");
        }

        if (p.containsKey("rotation")) {
            try {
                int r = Integer.parseInt(p.get("rotation"));
                if (t.mirror() == Transform.Mirror.LEFT_RIGHT) r = (8 - r) & 15;
                else if (t.mirror() == Transform.Mirror.FRONT_BACK) r = (16 - r) & 15;
                r = (r + 4 * t.rotationSteps()) & 15;
                p.put("rotation", Integer.toString(r));
            } catch (NumberFormatException ignored) { /* not a numeric rotation property */ }
        }

        // north/east/south/west connection properties (fences, panes, walls, vines, redstone, ...)
        boolean anySide = false;
        for (String s : SIDES) anySide |= p.containsKey(s);
        if (anySide) {
            Map<String, String> old = new TreeMap<>();
            for (String s : SIDES) if (p.containsKey(s)) old.put(s, p.remove(s));
            for (Map.Entry<String, String> e : old.entrySet()) p.put(t.dir(e.getKey()), e.getValue());
        }

        if (mirrored) {
            if (p.containsKey("hinge")) p.put("hinge", swapLeftRight(p.get("hinge")));
            if (name.contains("chest") && p.containsKey("type")) p.put("type", swapLeftRight(p.get("type")));
        }

        if (p.containsKey("shape")) {
            if (name.endsWith("_stairs")) {
                if (mirrored) p.put("shape", swapLeftRightSuffix(p.get("shape")));
            } else if (name.endsWith("rail")) {
                p.put("shape", railShape(p.get("shape"), t));
            }
        }
        return in.withProperties(p);
    }

    private static String swapLeftRight(String v) {
        return v.equals("left") ? "right" : v.equals("right") ? "left" : v;
    }

    private static String swapLeftRightSuffix(String v) {
        if (v.endsWith("_left")) return v.substring(0, v.length() - 5) + "_right";
        if (v.endsWith("_right")) return v.substring(0, v.length() - 6) + "_left";
        return v;
    }

    /** Rail shapes: north_south, east_west, ascending_X, and the four curves like south_east. */
    static String railShape(String shape, Transform t) {
        if (shape.startsWith("ascending_")) {
            return "ascending_" + t.dir(shape.substring("ascending_".length()));
        }
        String[] parts = shape.split("_");
        if (parts.length != 2) return shape;
        String a = t.dir(parts[0]);
        String b = t.dir(parts[1]);
        boolean aNs = a.equals("north") || a.equals("south");
        boolean bNs = b.equals("north") || b.equals("south");
        if (aNs && bNs) return "north_south";
        if (!aNs && !bNs) return "east_west";
        return (aNs ? a + "_" + b : b + "_" + a); // curves are named <north|south>_<east|west>
    }
}
