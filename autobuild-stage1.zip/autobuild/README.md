# AutoBuild — Stage 1 (schematic core)

Client-side Fabric mod for Minecraft Java **1.21.11** that will build `.litematic` schematics with a
dependency-aware planner and human-like movement. **This is Stage 1 of 6.** It contains the parts that
everything else depends on: schematic parsing, rotation/mirroring, and exact world comparison.
There is no building, movement, GUI or keybind yet — nothing in this zip places a block.

## Architecture

| Layer | Package | Depends on Minecraft? | Purpose |
|---|---|---|---|
| Core | `dev.autobuild.core.*` | **No** (plain Java 21) | NBT, `.litematic` reader/writer, `Schematic`, `Transform`, `StateTransformer`, `StateMatcher`, `WorldComparator` |
| Client | `dev.autobuild.client.*` | Yes (Fabric, Yarn) | Command, later: world adapter, movement, interaction, GUI, keybind, renderer |

Why a client mod and no Litematica dependency: the `.litematic` format is simple and documented by its
implementation, parsing it ourselves removes a version-coupling risk, and a client mod is the only option
with reliable access to block states, the inventory, interaction packets and rendering. Mineflayer is not
used: it cannot be relied on for every interaction this project needs on 1.21.11.

The core has no Minecraft imports on purpose, so the planner can be tested quickly outside the game.
The client layer will implement `WorldComparator.WorldView` (Stage 2) by reading `ClientWorld`.

### Conventions

* **Anchor** = minimum corner (lowest x, y, z) of the *transformed* schematic's bounding box.
* **Transform order**: mirror first, then rotation. Rotation is clockwise seen from above (north → east).
  `LEFT_RIGHT` flips Z (north↔south). `FRONT_BACK` flips X (east↔west).
* **Cell index** = `(y * sizeZ + z) * sizeX + x`.
* **Match modes**: `EXACT` compares every property (final verification). `PLACEMENT` ignores properties the
  game derives from neighbours or redstone (fence/wall/pane connections, stair/rail `shape`, `powered`, `distance`, ...)
  because a builder cannot choose them. Use PLACEMENT to decide if a cell still needs work.
* Comparison statuses: `MATCH`, `MISSING` (air, needs block), `INCORRECT` (wrong block there),
  `EXTRA` (schematic wants air, world has a block), `CLEAR`, `UNKNOWN` (chunk not loaded — never treated as missing).

## Windows setup

1. Install **JDK 21** (for example Eclipse Temurin 21). Check: `java -version` shows 21.
2. Install an IDE (IntelliJ IDEA Community is fine) — optional.
3. Get the Gradle wrapper (binary files can't be shipped in this zip):
   * Download <https://github.com/FabricMC/fabric-example-mod> (branch `1.21.11`), and copy the `gradle` folder,
     `gradlew` and `gradlew.bat` into this project folder.
4. Open <https://fabricmc.net/develop>, choose 1.21.11, and compare with `gradle.properties`.
   If `yarn_mappings`, `loader_version`, `loom_version` or `fabric_api_version` differ, use the website's numbers.
   (Values in the zip were gathered from third-party projects targeting 1.21.11, not from that page.)
5. In this folder (PowerShell or cmd):

```
gradlew.bat build
```

The mod jar appears in `build\libs\autobuild-0.1.0.jar` (not the `-sources` jar).

## Tests

Core tests need no Minecraft and no Gradle:

```
mkdir out
javac -d out (Get-ChildItem -Recurse src\main\java\dev\autobuild\core,src\test\java -Filter *.java).FullName
java -cp out dev.autobuild.core.schematic.SelfTest
```

(In cmd, list the files manually or use `gradlew.bat selfTest`.) Expected last line: `61 passed, 0 failed`.

Inspect any schematic from the command line:

```
gradlew.bat inspect -Pfile=C:\Users\YOU\AppData\Roaming\.minecraft\schematics\yourbuild.litematic
```

### In-game test (Stage 1)

1. Copy the jar and **Fabric API** into `%APPDATA%\.minecraft\mods`, launch the Fabric 1.21.11 profile.
2. In a world run `/autobuild exporttest` — writes `schematics\autobuild_test_house.litematic`
   (also provided as `testdata\autobuild_test_house.litematic`).
3. Run `/autobuild inspect autobuild_test_house.litematic`. Expect: 7 x 7 x 7, 229 non-air blocks, 19 palette entries.
4. **Real-file check (important):** run `/autobuild inspect` on a schematic that Litematica saved, and compare the
   block total and size with Litematica's material list / schematic info. The unit tests only prove the reader
   agrees with this project's writer; a real Litematica file is the independent check.

## Known limitations (Stage 1)

* Compile status: the pure-Java core was compiled and tested (61 checks). The Fabric part
  (`AutoBuildClient`, `build.gradle`) could **not** be compiled where this was written (no network); expect to fix
  small Yarn-name or version mismatches on first build. Send the compiler output and I'll fix it.
* Litematic versions 5–7 only. Schematics from older Minecraft versions may contain renamed blocks/properties;
  Litematica runs data fixers when loading, this project does not. Stage 2 will list palette names that don't exist in the 1.21.11 registry.
* Entities and block-entity data (chest contents, sign text, banner patterns) are ignored.
* Dense `int[]` storage; bounding boxes above 100 million cells are rejected.
* Property transforms cover facing, axis, rotation, side connections, stair shape, rail shape, door hinge, chest type.
  Not yet special-cased: `orientation` (crafters, jigsaws), bed/head multi-block quirks, banners' patterns, redstone
  component edge cases. Unknown properties are left unchanged.
* `DERIVED_PROPERTIES` in `StateMatcher` is a reasoned list, not exhaustive; it is meant to be tuned.

## Roadmap

| Stage | Contents | Status |
|---|---|---|
| 1 | NBT, `.litematic` reader/writer, transforms, state matcher, comparator, command, test schematic | **done** (core tested) |
| 2 | `ClientWorld` adapter, registry validation of palette, ghost/preview renderer, batched comparison | next |
| 3 | Dependency graph and placement rules (support, gravity, doors, torches, ...), cycle handling, reachability | |
| 4 | Movement/pathing, interaction (reach, line of sight, face and hit point), creative + survival modes | |
| 5 | Retry/recovery, persistence + resume, pause/stop, structured logs | |
| 6 | GUI, keybind, settings, final verification pass | |
