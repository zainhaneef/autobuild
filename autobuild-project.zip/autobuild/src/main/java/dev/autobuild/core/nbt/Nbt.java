package dev.autobuild.core.nbt;

import java.io.*;
import java.util.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class Nbt {
    public static class CompoundTag {
        private final Map<String, Object> map = new HashMap<>();

        public void put(String key, Object value) { map.put(key, value); }
        public Object get(String key) { return map.get(key); }
        public String getString(String key) { Object o = map.get(key); return o instanceof String ? (String) o : ""; }
        public int getInt(String key) { Object o = map.get(key); return o instanceof Number ? ((Number) o).intValue() : 0; }
        public CompoundTag getCompound(String key) { Object o = map.get(key); return o instanceof CompoundTag ? (CompoundTag) o : new CompoundTag(); }
        @SuppressWarnings("unchecked")
        public List<Object> getList(String key) { Object o = map.get(key); return o instanceof List ? (List<Object>) o : null; }
        public Map<String, Object> getMap() { return map; }
    }

    public static CompoundTag readCompressed(File file) throws IOException {
        try (InputStream in = new FileInputStream(file);
             BufferedInputStream bin = new BufferedInputStream(in);
             GZIPInputStream gzin = new GZIPInputStream(bin)) {
            return read(gzin);
        }
    }

    public static void writeCompressed(CompoundTag tag, File file) throws IOException {
        try (OutputStream out = new FileOutputStream(file);
             BufferedOutputStream bout = new BufferedOutputStream(out);
             GZIPOutputStream gzout = new GZIPOutputStream(bout)) {
            write(tag, gzout);
        }
    }

    public static CompoundTag read(InputStream in) throws IOException {
        DataInputStream dis = new DataInputStream(in);
        byte type = dis.readByte();
        if (type != 10) throw new IOException("Root tag must be a Compound");
        readString(dis);
        return readCompoundTag(dis);
    }

    public static void write(CompoundTag tag, OutputStream out) throws IOException {
        DataOutputStream dos = new DataOutputStream(out);
        dos.writeByte(10);
        dos.writeUTF("");
        writeCompoundTag(tag, dos);
    }

    private static CompoundTag readCompoundTag(DataInputStream dis) throws IOException {
        CompoundTag tag = new CompoundTag();
        while (true) {
            byte type = dis.readByte();
            if (type == 0) break;
            String name = readString(dis);
            tag.put(name, readTagPayload(dis, type));
        }
        return tag;
    }

    private static void writeCompoundTag(CompoundTag tag, DataOutputStream dos) throws IOException {
        for (Map.Entry<String, Object> entry : tag.getMap().entrySet()) {
            byte type = getTagType(entry.getValue());
            dos.writeByte(type);
            dos.writeUTF(entry.getKey());
            writeTagPayload(entry.getValue(), type, dos);
        }
        dos.writeByte(0);
    }

    private static byte getTagType(Object val) {
        if (val instanceof Byte) return 1;
        if (val instanceof Short) return 2;
        if (val instanceof Integer) return 3;
        if (val instanceof Long) return 4;
        if (val instanceof Float) return 5;
        if (val instanceof Double) return 6;
        if (val instanceof byte[]) return 7;
        if (val instanceof String) return 8;
        if (val instanceof List) return 9;
        if (val instanceof CompoundTag) return 10;
        if (val instanceof int[]) return 11;
        if (val instanceof long[]) return 12;
        return 10;
    }

    private static Object readTagPayload(DataInputStream dis, byte type) throws IOException {
        switch (type) {
            case 1: return dis.readByte();
            case 2: return dis.readShort();
            case 3: return dis.readInt();
            case 4: return dis.readLong();
            case 5: return dis.readFloat();
            case 6: return dis.readDouble();
            case 7: byte[] b = new byte[dis.readInt()]; dis.readFully(b); return b;
            case 8: return readString(dis);
            case 9:
                byte et = dis.readByte();
                int len = dis.readInt();
                List<Object> list = new ArrayList<>(len);
                for (int i = 0; i < len; i++) list.add(readTagPayload(dis, et));
                return list;
            case 10: return readCompoundTag(dis);
            case 11: int[] i11 = new int[dis.readInt()]; for (int i=0; i<i11.length; i++) i11[i] = dis.readInt(); return i11;
            case 12: long[] l12 = new long[dis.readInt()]; for (int i=0; i<l12.length; i++) l12[i] = dis.readLong(); return l12;
            default: throw new IOException("Unknown NBT type: " + type);
        }
    }

    private static void writeTagPayload(Object val, byte type, DataOutputStream dos) throws IOException {
        switch (type) {
            case 1: dos.writeByte((Byte) val); break;
            case 2: dos.writeShort((Short) val); break;
            case 3: dos.writeInt((Integer) val); break;
            case 4: dos.writeLong((Long) val); break;
            case 5: dos.writeFloat((Float) val); break;
            case 6: dos.writeDouble((Double) val); break;
            case 7: byte[] b = (byte[]) val; dos.writeInt(b.length); dos.write(b); break;
            case 8: dos.writeUTF((String) val); break;
            case 9:
                List<?> list = (List<?>) val;
                byte et = list.isEmpty() ? 10 : getTagType(list.get(0));
                dos.writeByte(et);
                dos.writeInt(list.size());
                for (Object o : list) writeTagPayload(o, et, dos);
                break;
            case 10: writeCompoundTag((CompoundTag) val, dos); break;
            case 11: int[] i11 = (int[]) val; dos.writeInt(i11.length); for (int i : i11) dos.writeInt(i); break;
            case 12: long[] l12 = (long[]) val; dos.writeInt(l12.length); for (long l : l12) dos.writeLong(l); break;
        }
    }

    private static String readString(DataInputStream dis) throws IOException { return dis.readUTF(); }
}
