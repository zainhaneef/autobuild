package dev.autobuild.core.schematic;

import dev.autobuild.core.model.BlockStateKey;
import dev.autobuild.core.nbt.Nbt;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/** Writes a single-region .litematic (used for the bundled test structure and round-trip tests). */
public final class LitematicWriter {
    private LitematicWriter() {}

    public static void write(Schematic s, Path file, String author) throws IOException {
        Nbt.writeCompressed(file, toRoot(s, author), "");
    }

    public static Map<String, Object> toRoot(Schematic s, String author) {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("Version", 6);
        root.put("SubVersion", 1);
        root.put("MinecraftDataVersion", s.dataVersion);

        Map<String, Object> meta = new LinkedHashMap<>();
        meta.put("Name", s.name);
        meta.put("Author", author);
        meta.put("Description", "");
        meta.put("RegionCount", 1);
        meta.put("TotalVolume", s.volume());
        meta.put("TotalBlocks", s.countNonAir());
        Map<String, Object> enc = vec(s.sizeX, s.sizeY, s.sizeZ);
        meta.put("EnclosingSize", enc);
        root.put("Metadata", meta);

        Map<String, Object> region = new LinkedHashMap<>();
        region.put("Position", vec(0, 0, 0));
        region.put("Size", vec(s.sizeX, s.sizeY, s.sizeZ));
        region.put("BlockStatePalette", paletteList(s.palette));
        region.put("BlockStates", packBlocks(s.blocks, s.palette.length));
        region.put("TileEntities", new ArrayList<>());
        region.put("Entities", new ArrayList<>());
        region.put("PendingBlockTicks", new ArrayList<>());
        region.put("PendingFluidTicks", new ArrayList<>());

        Map<String, Object> regions = new LinkedHashMap<>();
        regions.put("Main", region);
        root.put("Regions", regions);
        return root;
    }

    public static Map<String, Object> vec(int x, int y, int z) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("x", x);
        m.put("y", y);
        m.put("z", z);
        return m;
    }

    public static List<Object> paletteList(BlockStateKey[] palette) {
        List<Object> list = new ArrayList<>();
        for (BlockStateKey k : palette) {
            Map<String, Object> e = new LinkedHashMap<>();
            e.put("Name", k.name());
            if (!k.properties().isEmpty()) {
                Map<String, Object> props = new LinkedHashMap<>(k.properties());
                e.put("Properties", props);
            }
            list.add(e);
        }
        return list;
    }

    /** Bit-packs palette indices exactly like Litematica (non-aligned, entries may span two longs). */
    public static long[] packBlocks(int[] indices, int paletteSize) {
        int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(paletteSize - 1));
        long mask = (1L << bits) - 1L;
        long[] arr = new long[(int) (((long) indices.length * bits + 63) / 64)];
        for (int i = 0; i < indices.length; i++) {
            long v = indices[i] & mask;
            long startOffset = (long) i * bits;
            int startArr = (int) (startOffset >>> 6);
            int endArr = (int) ((((long) i + 1) * bits - 1) >>> 6);
            int startBit = (int) (startOffset & 63L);
            arr[startArr] = (arr[startArr] & ~(mask << startBit)) | (v << startBit);
            if (startArr != endArr) {
                int firstPart = 64 - startBit;       // bits stored in the first long
                int remaining = bits - firstPart;    // bits spilling into the second long
                long lowMask = (1L << remaining) - 1L;
                arr[endArr] = (arr[endArr] & ~lowMask) | (v >>> firstPart);
            }
        }
        return arr;
    }
}
